module.exports = {
  'secret': 'supersecret'
};